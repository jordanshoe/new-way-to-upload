
// function openNav(){
//     // alert("testing function");
//     var open = document.getElementById('myNav');
//         open.style.width = "50%";
// }

// function closeNav(){
//     // alert('testing close button');
//     var close = document.getElementById('myNav');
//     close.style.width = "0%";
// }


$(function(){

    $('#open').click(function(){
            $('#myNav').css('width','50%');
    });
    $('#close').click(function(){
        $('#myNav').css('width','0');
});








});
