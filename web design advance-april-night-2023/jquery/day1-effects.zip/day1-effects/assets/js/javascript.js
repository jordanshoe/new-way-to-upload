$(function(){

    // hide,show, and toggle methods
    $('#hide-btn').click(function(){
        $('#demo').hide(1200);
    });
    $('#show-btn').click(function(){
        $('#demo').show('slow');
    });
    $('#toggle-btn').click(function(){
        $('#demo').toggle('fast');
    });

    //fade effects

    $('#fade-out-btn').click(function(){
        $('.box1').fadeOut('fast');
        $('.box2').fadeOut('slow');
        $('.box3').fadeOut(1200);

    });

    $('#fade-in-btn').click(function(){
        $('.box1').fadeIn('fast');
        $('.box2').fadeIn('slow');
        $('.box3').fadeIn(1200);

    });






});