

$(function(){

    // auto slide

    function autoSlide(){
        interval = setInterval(function(){
            moveRight();
        },2000)
    }
    //call the function
    autoSlide();

    //stop auto and do manual
    $('#slider ul li').hover(function(){
        clearInterval(interval);
    },function(){
        autoSlide();
    })

    $('#slider a').hover(function(){
        clearInterval(interval);
    },function(){
        autoSlide();
    })






//   slider

    var sliderWidth =$('#slider ul li').width();
        console.log(sliderWidth);

    
    var sliderHeight =$('#slider ul li').height();
        console.log(sliderHeight);

    var sliderCount = $('#slider ul li').length;
        console.log(sliderCount);

    var sliderUIWidth = sliderWidth * sliderCount;
        console.log(sliderUIWidth);


    $('#slider').css({
        width: sliderWidth,
        height: sliderHeight,
        border: '1px solid red'
    })

    $('#slider ul').css({
        width: sliderUIWidth,
        height: sliderHeight,
        marginLeft: -sliderWidth
        
    })

    $('#slider ul li').last().prependTo('#slider ul');


    function moveLeft(){
        // alert('testing button');
        $('#slider ul').animate({
            left:sliderWidth
        },2000,function(){
            // alert('testing callback');
            $('#slider ul li').last().prependTo('#slider ul');
            $('#slider ul').css('left','0');
        })
    }

    // prev button
    $('a.control_prev').click(function(){
        moveLeft();
    })


    function moveRight(){
        // alert('testing function');
        $('#slider ul').animate({
            left:-sliderWidth
        },2000,function(){
            // alert('testing callback');
            $('#slider ul li').first().appendTo('#slider ul');
            $('#slider ul').css('left','0');
        })
    }

     // next button
     $('a.control_next').click(function(){
        moveRight();
    })

});